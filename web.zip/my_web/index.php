<!DOCTYPE html>

<html class="js">
<head>
<title>Resume | Vasanthakumar</title>
<!-- meta-tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="vasanthakumar,vasanthakumar555,vasanth,hacker" />
<meta name="description" content="hi, i am vasanth it's my personal resume website. thanks for coming" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta-tags -->
<link rel="icon" href="images/v.png" />
<!-- Custom-Files -->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link href="css/font-awesome.css" rel="stylesheet"> <!-- Font-Awesome-Icons-CSS -->	
<link rel="stylesheet" href="css/swipebox.css"> <!-- For-Gallery-Swipebox-CSS -->
<!-- //Custom-Files -->
<!--preloader-->
<link rel="stylesheet" href="css/preloader.css">



</head>
<body>
<div id="preloader"></div>
	<!-- Header -->
	<div class="banner-agile">
		<div class="myheading">
			<h1><a href="index.php">Personal Website</a></h1>
		</div>	
		<div class="container">
			<div class="banner-info-w3l">
				<h2>Hi, I am Vasantha Kumar</h2>
				<h4><a href="docs/resume.pdf" download="vasanth-resume.pdf" >Download Resume</a></h4>
			</div>
		</div>
	</div>
	<div class="nav-agile">
		<div class="container">
			<!-- Navigation -->
			<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right margin-top cl-effect-2">
							<li><a class="scroll2" href="index.php"><span data-hover="Home">Home</span></a></li>
							<li><a class="scroll" href="#about"><span data-hover="About">About</span></a></li>
							<li><a class="scroll" href="#skills"><span data-hover="Skills">Skills</span></a></li>
							<li><a class="scroll" href="#experience"><span data-hover="Academics">Academics</span></a></li>
							<li><a class="scroll" href="#portfolio"><span data-hover="Projects">Projects</span></a></li>
							<li><a class="scroll" href="#contact"><span data-hover="Contact">Contact</span></a></li>
						</ul>
						<div class="clearfix"></div>
					</div><!-- /.navbar-collapse -->
					<div class="clearfix"></div>
			</nav>
		</div>
	</div>
	<!-- //Navigation -->
<!-- //Header -->
	
<!-- main-section-starts-here -->
	<!-- About-starts-here -->
	<div class="about" id="about">
		<div class="container">
			<h3 class="w3l_head">About Me</h3>
			<div class="w3l-grids-about">
				<div class="col-md-5 w3ls-ab-right">
					<div class="agile-about-right-img">
						<img src="images/vasanth.jpg" alt="">
					</div>
				</div>
				<div class="col-md-7 w3ls-agile-left">
					<div class="w3ls-agile-left-info">
						<div class="wel-left animated wow fadeInLeft" data-wow-delay=".5s">
							<div class="icon-w3l">
								<i class="hovicon effect-2 sub-a"><span class="fa fa-code" aria-hidden="true"></span></i>
							</div>
							<div class="text-w3l">
								<h4>WEB DEVELOPER</h4>
								<p>Developing a best responsive website for any domainn using php, html5, css ,javascript</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="w3ls-agile-left-info">
						<div class="wel-left animated wow fadeInLeft" data-wow-delay=".5s">
							<div class="icon-w3l">
								<i class="hovicon effect-2 sub-a"><span class="fa fa-desktop" aria-hidden="true"></span></i>
							</div>							
							<div class="text-w3l">
								<h4>PROGRAMMER</h4>
								<p>Writing  a effective program in various languages such as java,c,c++</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="w3ls-agile-left-info">
						<div class="wel-left animated wow fadeInLeft" data-wow-delay=".5s">
							<div class="icon-w3l">
								<i class="hovicon effect-2 sub-a"><span class="fa fa-mobile-phone" aria-hidden="true"></span></i>
							</div>
							<div class="text-w3l">
								<h4>ANDROID APP DEVELOPER</h4>
								<p>Creating new andriod application for simple message service, rss news feed and other requirements</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="w3ls-agile-left-info">
						<div class="wel-left animated wow fadeInLeft" data-wow-delay=".5s">
							<div class="icon-w3l">
								<i class="hovicon effect-2 sub-a"><span class="fa fa-power-off" aria-hidden="true"></span></i>
							</div>
							<div class="text-w3l">
								<h4>SYSTEM ADMIN</h4>
								<p>Installing & Configuring various Hardware and Operating system such as anybrand of devices, and Linux, Windows and Android with best-in-scale performance</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //About-ends-here -->
	
	
	<!--Skills-starts-here -->
	<div class="wthreeskills" id="skills">
		<div class="container-fluid">
			<h3>MY SKILLS</h3>

			<div class="wthreeskills-grids">
				<div class="col-md-6 wthreeskills-grid wthreeskills-grid-2">
					<h4>PROFESSIONAL SKILLS</h4>

					<div class="bar_group">
						<div class='bar_group__bar thin' label='WEB DESIGN' show_values='true' tooltip='true' value='95'></div>
						<div class='bar_group__bar thin' label='ANDROID APPLICATION DEVELOPMENT' show_values='true' tooltip='true' value='75'></div>
						<div class='bar_group__bar thin' label='JAVA PROGRAMMING' show_values='true' tooltip='true' value='80'></div>
						<div class='bar_group__bar thin' label='DATABASE ADMINISTRATION' show_values='true' tooltip='true' value='85'></div>
						<div class='bar_group__bar thin' label='PHOTOSHOP' show_values='true' tooltip='true' value='65'></div>
					</div>

				</div>
				<div class="col-md-6 wthreeskills-grid wthreeskills-grid-1">
					<h4>TECHNICAL SKILLS</h4>

					<!-- Tabs -->
					<div class="tabs">
						<div class="sap_tabs">
							<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
								<ul class="resp-tabs-list">
									<li class="resp-tab-item"><span>C/Python/JAVA</span></li>
									<li class="resp-tab-item"><span>Android App Developer</span></li>
									<li class="resp-tab-item"><span>Web Developer</span></li>
								</ul>

								<div class="resp-tabs-container">
									<div class="tab-1 resp-tab-content">
										<p>"When someone says: 'I want a programming language in which I need only say what I wish done',give him a chocolate".</p>
										<div class="w3lsstatsaits-info">
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-1">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='9000' data-delay='.5' data-increment=4>80</div>
												<p>C</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-2">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='17000' data-delay='8' data-increment="1">70</div>
												<p>Python</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-3">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='12000' data-delay='.5' data-increment="11">75</div>
												<p>JAVA</p>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
									<div class="tab-2 resp-tab-content">
										<p>"Realistically this is not something you’re going to learn in a day. The experience of learning to develop is pleasurable and empowering because there’s a real sense of progress and a learning curve that’s as challenging as you choose to make it." </p>
										<div class="w3lsstatsaits-info">
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-1">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='9000' data-delay='.5' data-increment="1">1</div>
												<p>Commercial</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-2">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='17000' data-delay='8' data-increment="1">1</div>
												<p>Essential</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-3">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='12000' data-delay='.5' data-increment="11">2</div>
												<p>Personal</p>
											</div>
											<div class="clearfix"></div>
										</div>
									</div> 
									<div class="tab-3 resp-tab-content">
										<p> “Create your own visual style… let it be unique for yourself and yet identifiable for others.”<br />If there’s one thing you learn by working on a lot of different Web sites, it’s that almost any design idea–no matter how appallingly bad–can be made usable in the right circumstances, with enough effort.</p>
										<div class="w3lsstatsaits-info">
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-1">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='9000' data-delay='.5' data-increment="1">1</div>
												<p>Commercial Websites</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-2">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='17000' data-delay='8' data-increment="1">1</div>
												<p>Industrial Websites</p>
											</div>
											<div class="col-md-4 w3lsstatsaits-grid w3lsstatsaits-grid-3">
												<div class="w3lsstatsaitsstats counter" data-slno='1' data-min='0' data-max='12000' data-delay='.5' data-increment="11">3</div>
												<p>Personal Websites</p>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- //Tabs -->
				</div>
				<div class="clearfix"></div>
			</div>

		</div>
	</div>
	<!-- //Skills-ends-here -->
	
	<!-- services-starts-here -->
	<div class="services" id="service"> 
		<div class="container">	 
			<h3 class="agileits-title">MY INTERESTS</h3>
			<div class="services-w3ls-row">
				<div class="col-md-3 services-grids">
					<div class="w3agile-servs-img">
						<div class="icon-holder">
							<span class="glyphicon glyphicon-queen" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Games </h4>
						<p class="description">I am always addict to games and it provide some additional skills</p>
					</div>
				</div>
				<div class="col-md-3 services-grids">
					<div class="w3agile-servs-img">
						<div class="icon-holder">
							<span class="fa fa-gears icon" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Logical Resoning</h4>
						<p class="description">I found new solution or optimal for problems</p>
					</div>
				</div>
				<div class="col-md-3 services-grids">
					<div class="w3agile-servs-img">
						<div class="icon-holder">
							<span class="fa fa-code" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Web Design</h4>
						<p class="description">I love webdesigning, design an attractive one.</p>
					</div>
				</div> 
				<div class="col-md-3 services-grids">
					<div class="w3agile-servs-img">
						<div class="icon-holder">
							<span class="fa fa-desktop" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Programmer</h4>
						<p class="description">I am skilled programmer and debugger</p>
					</div>
				</div> 	
				<div class="clearfix"> </div>
			</div>	 			
		</div>	 			
	</div>			
	<!-- //services-ends-here -->
	
	<!-- Experience-starts-here -->
	<div class="aitsresumewthree" id="experience">
		<div class="container">
			<div class="aitsresumewthree-tag">
				<h3 class="title">Academic Details</h3>
			</div>
			<div class="load_more">
				<ul id="myList">
				<li>
						<div class="l_g">
							<div class="l_g_r g_r">
								<div class="work">
									<h4 class="title title2">EDUCATION</h4>
									<div class="work-info"> 
										<div class="col-md-6 work-grid work-left"> 
											<h4>2014-2018</h4>
										</div>
										<div class="col-md-6 work-grid work-right"> 
											<h5 class="sch">Graduate</h5>
											<p>University college of engineering villupuram.</p>
											<p>CGPA: 7.63</p>
										</div>
										<div class="clearfix"> </div>
									</div>
									<div class="work-info"> 
										<div class="col-md-6 work-grid work-right work-right2"> 
											<h4>2013-2014</h4>
										</div>
										<div class="col-md-6 work-grid work-left work-left2"> 
											<h5 class="univ">HSC</h5>
											<p>Z.K.M.Higher Secondary School</p>
											<p>percentage: 83.6%</p>
										</div>
										<div class="clearfix"> </div>
									</div>
									<div class="work-info"> 
										<div class="col-md-6 work-grid work-left"> 
											<h4>2011-2012</h4>
										</div>
										<div class="col-md-6 work-grid work-right"> 
											<h5 class="sch">SSLC</h5>
											<p>Z.K.M.Higher Secondary School</p>
											<p>percentage: 82.4%</p>
										</div>
										<div class="clearfix"> </div>
									</div>
								</div>
							</div>
						</div>
					</li>
					
				</ul>
				<!--div class="wow fadeInUp" id="loadMore">Show More <i class="fa fa-chevron-down" aria-hidden="true"></i></div>
				<div class="wow fadeInDown" id="showLess">Show Less <i class="fa fa-chevron-up" aria-hidden="true"></i></div-->
			</div>
		</div>
	</div>

	<!-- //Experience-ends-here -->
	<!-- Portfolio-starts-here -->
	<div id="portfolio" class="portfolio">
		<div class="container">
			<h3 class="agile-title">My Projects & Achievements</h3>
			<div class="gallery_gds">
				<div class="filtr-container">
					<div class="col-md-3 filtr-item" data-category="1, 4" data-sort="Busy streets">
						<div class="agileits-img">
							<a href="images/agnimithra.jpg" class="swipebox" title="For Inviting students to attend the symposium, I develop a website">
								<img src="images/agnimithrap.jpg" alt="" class="img-responsive img-style row2" /> 
							</a> 
						</div>
						<div class="agileits-img">
							<a href="images/resume.jpg" class="swipebox" title="To be unique in approaching for job i have developed my own website and hosted on vasanth.16mb.com">
								<img src="images/resumep.jpg" alt="" class="img-responsive img-style row2" /> 
							</a> 
						</div>
					</div>
					<div class="col-md-6 filtr-item" data-category="2, 3" data-sort="Luminous night">
						<a href="images/martifier.jpg" class="swipebox" title="Martifier Technology is a one of the best IT services company in Chennai and CEO is Mr.Rajaram, I design a new web for that company using PHP language, also include blogspot, google maps location creation and embedded into website, Career web Registration form. This website hosted on martifier.com">
							<img src="images/martifierp.jpg" alt="" class="img-responsive img-style row2" />
						</a>	
						<div class="col-md-6 agileits-img g2">
							<a href="images/webwon.jpg" class="swipebox" title="Won the first price in web design event conducted by University College of Engineering Tindivanam.">
								<img src="images/webwonp.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
						<div class="col-md-6 agileits-img g4">
							<a href="images/pptwon.jpg" class="swipebox" title="Won the first price in paper presentation event conducted by University College of Engineering Tindivanam.">
								<img src="images/pptwonp.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
						<div class="clearfix"> </div>
						<a href="images/wiki.jpg" class="swipebox" title="Participate in World Record workshop “Hack Geeks” and Trained by Microsoft MVP Mr.Venkat.">
							<img src="images/wikip.jpg" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
					<div class="col-md-3 filtr-item" data-category="1, 4" data-sort="Busy streets">
						<div class="agileits-img">
							<a href="images/placement.jpg" class="swipebox" title="For my college,I would like to do something, so I created a website for placement for helping other students">
								<img src="images/placementp.jpg" alt="" class="img-responsive img-style row2" /> 
							</a> 
						</div>
						<div class="agileits-img">
							<a href="images/ccpt.jpg" class="swipebox" title="Participated in Grid and Cloud Computing workshop and Android App Development workshop in University college of Engineering Villupuram.">
								<img src="images/ccptp.jpg" alt="" class="img-responsive img-style row2" /> 
							</a> 
						</div>
					</div>
				   <div class="clearfix"> </div>
				</div>
			</div>
		</div>  
	</div>    
	<!-- Portfolio-ends-here -->
	
	<!-- contact-starts-here -->
	<div class="contact" id="contact">	
		<h3 class="agile-contact"> Contact Me</h3>
		<div class="contact-agile">
			<div class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3930.7335110931476!2d77.32060121434154!3d9.872710492938458!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b070f05621a92c5%3A0x122efc03ca55594d!2sKeezha+sindalacherry!5e0!3m2!1sen!2sin!4v1505495616788"allowfullscreen></iframe>
			</div>
			<div class="contact-left-agile">
				<h4>Address</h4>
				
				<div class="add-w3ls-main">
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
					<div class="add-w3ls2">
						<h5>Location</h5>
						<p>25, south street,kezhasindhalaicherry</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="add-w3ls-main">	
						<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
					<div class="add-w3ls2">
						<h5>Email</h5>
						<p><a href="mailto:info@example.com">vasanthakumartech@gmail.com</a></p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="add-w3ls-main">	
						<span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> 
					<div class="add-w3ls2">
						<h5>Call Me</h5>
						<p>+919788145142</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>    
			<div class="contact-right-w3l">
				<div class="contact-form">
					<form action="sentMail.php" method="post">
						<input placeholder="NAME" name="fname" type="text" required="" />
						<input placeholder="LASTNAME" name="lname" type="text" required="" />
						<input placeholder="E-MAIL" name="email" type="email" required="" />
						<textarea placeholder="TYPE YOUR MESSAGE......" required="" name="text"></textarea>
						<input type="submit" value="Submit" name="submit">
					</form>
				</div> 
			</div> 
			<div class="clearfix"> </div>
		</div>  
	</div>  		
	<!-- //contact-ends-here -->
		
	<!-- copyright-starts-here -->
	<div class="copy-section">
		<div class="container">
			<div class="footer-top">
				<p>© 2017 Vasanth'S Resume. All rights reserved | Design by <a href="http://vasanth.16mb.com">VasanthaKumar</a></p>
			</div>
		</div>
	</div>
	<!-- copyright-ends-here -->
	<!-- //main-section-ends-here -->

	
	<!-- Custom-JavaScript-Files -->

		<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script> <!-- Default-JavaScript-File -->
		<script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
	
		<!-- for-projects -->
			<!-- swipe box js -->
			<script src="js/jquery.swipebox.min.js"></script> 
			<script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
			</script>
			<!-- //swipe box js --> 
			
			<script src="js/jquery.adipoli.min.js" type="text/javascript"></script>
			<script type="text/javascript"> 
				$(function(){ 
					$('.row2').adipoli({
						'startEffect' : 'overlay',
						'hoverEffect' : 'sliceDown'
					}); 
				});
				
			</script>
		<!-- //for-projects -->
		
		<!-- Horizontal-Tabs-JavaScript -->
			<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
			<script type="text/javascript">
				$(document).ready(function () {
					$('#horizontalTab').easyResponsiveTabs({
						type: 'default',
						width: 'auto',
						fit: true,
					});
				});
			</script>
		<!-- Horizontal-Tabs-JavaScript -->

		<!-- Stats-Number-Scroller-Animation-JavaScript -->
			<script src="js/waypoints.min.js"></script> 
			<script src="js/counterup.min.js"></script> 
			<script>
				jQuery(document).ready(function( $ ) {
					$('.counter').counterUp({
						delay: 10,
						time: 1000,
					});
				});
			</script>
		<!-- //Stats-Number-Scroller-Animation-JavaScript -->

		<!-- Progressive-Bars-JavaScript -->
			<script src="js/bars.js"></script>
		<!-- //Progressive-Bars-JavaScript -->

		<!-- for-experience -->
			<!-- Show-More-JavaScript -->
			<script>
				$(document).ready(function () {
					size_li = $("#myList li").size();
					x=1;
					$('#myList li:lt('+x+')').show();
					$('#loadMore').click(function () {
						x= (x+1 <= size_li) ? x+1 : size_li;
						$('#myList li:lt('+x+')').show();
					});
					$('#showLess').click(function () {
						x=(x-1<0) ? 1 : x-1;
						$('#myList li').not(':lt('+x+')').hide();
					});
				});
			</script>
			<!-- //Show-More-JavaScript -->
		<!-- //for-experience -->
	
		<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="js/move-top.js"></script>
			<script type="text/javascript" src="js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
		<!-- start-smoth-scrolling -->
		<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
<script type="text/javascript">
$(document).ready(function () {
    //Disable cut copy paste
    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
   
    //Disable mouse right click
    $("body").on("contextmenu",function(e){
        return false;
    });
});
</script>
 <script>
  jQuery(document).ready(function($) {  

// site preloader -- also uncomment the div in the header and the css style for #preloader
$(window).load(function(){
	$('#preloader').fadeOut('slow',function(){$(this).remove();});
});

});
	</script>
	
<!-- //Custom-JavaScript-Files -->

</body>
</html>